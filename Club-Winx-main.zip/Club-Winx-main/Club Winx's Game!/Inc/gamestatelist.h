#pragma once

enum GS_STATES
{
	RACING = 0,
	BOSS,
	RESTART,
	QUIT
};