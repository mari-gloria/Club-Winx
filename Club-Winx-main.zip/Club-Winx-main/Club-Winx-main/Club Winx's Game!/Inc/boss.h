#pragma once

void boss_load();
void boss_init();
void boss_update();
void boss_draw();
void boss_free();
void boss_unload();