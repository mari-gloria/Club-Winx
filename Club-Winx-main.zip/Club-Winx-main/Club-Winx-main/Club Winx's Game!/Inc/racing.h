#pragma once

void racing_load();
void racing_init();
void racing_update();
void racing_draw();
void racing_free();
void racing_unload();